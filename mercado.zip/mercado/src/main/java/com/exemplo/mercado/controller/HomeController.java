package com.exemplo.mercado.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HomeController {

    // Abre a tela de login ao iniciar o site
    @GetMapping("/")
    public String index() {
        return "login";
    }

    // Processa o login simples e vai para o painel do mercado
    @PostMapping("/entrar")
    public String entrar() {
        return "redirect:/painel";
    }

    // Painel principal do mercado
    @GetMapping("/painel")
    public String painel() {
        return "painel";
    }
}
