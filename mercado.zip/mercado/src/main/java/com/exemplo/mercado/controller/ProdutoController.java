package com.exemplo.mercado.controller;

import com.exemplo.mercado.model.Produto;
import com.exemplo.mercado.repository.CategoriaRepository;
import com.exemplo.mercado.repository.FornecedorRepository;
import com.exemplo.mercado.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/produtos")
public class ProdutoController {

    @Autowired private ProdutoRepository produtoRepo;
    @Autowired private CategoriaRepository categoriaRepo;
    @Autowired private FornecedorRepository fornecedorRepo;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("produtos", produtoRepo.findAll());
        return "produtos/lista";
    }

    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("produto", new Produto());
        model.addAttribute("categorias", categoriaRepo.findAll());
        model.addAttribute("fornecedores", fornecedorRepo.findAll());
        return "produtos/form";
    }

    @PostMapping
    public String salvar(@ModelAttribute Produto produto) {
        // Se nenhuma opção foi escolhida no select, evita salvar um objeto "vazio"
        if (produto.getCategoria() != null && produto.getCategoria().getId() == null) {
            produto.setCategoria(null);
        }
        if (produto.getFornecedor() != null && produto.getFornecedor().getId() == null) {
            produto.setFornecedor(null);
        }
        produtoRepo.save(produto);
        return "redirect:/produtos";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model) {
        Optional<Produto> produto = produtoRepo.findById(id);
        if (produto.isEmpty()) {
            return "redirect:/produtos";
        }
        model.addAttribute("produto", produto.get());
        model.addAttribute("categorias", categoriaRepo.findAll());
        model.addAttribute("fornecedores", fornecedorRepo.findAll());
        return "produtos/form";
    }

    @GetMapping("/{id}/excluir")
    public String excluir(@PathVariable Long id) {
        produtoRepo.deleteById(id);
        return "redirect:/produtos";
    }
}
