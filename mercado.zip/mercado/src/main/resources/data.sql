-- Categorias (ids gerados automaticamente)
INSERT INTO categoria (nome) VALUES ('Alimentos');
INSERT INTO categoria (nome) VALUES ('Bebidas');

-- Fornecedores
INSERT INTO fornecedor (razao_social, cnpj) VALUES ('Distribuidora Alimentos Brasil LTDA', '12.345.678/0001-90');
INSERT INTO fornecedor (razao_social, cnpj) VALUES ('Bebidas Joinville S/A', '98.765.432/0001-10');

-- Clientes
INSERT INTO cliente (nome, cpf) VALUES ('Carlos Silva', '111.222.333-44');
INSERT INTO cliente (nome, cpf) VALUES ('Ana Souza', '555.666.777-88');

-- Produtos (FKs resolvidas por consulta, sem depender de ids fixos)
INSERT INTO produto (nome, preco, estoque, categoria_id, fornecedor_id)
VALUES ('Arroz Tipo 1 - 5kg', 28.90, 50,
        (SELECT id FROM categoria WHERE nome = 'Alimentos'),
        (SELECT id FROM fornecedor WHERE cnpj = '12.345.678/0001-90'));

INSERT INTO produto (nome, preco, estoque, categoria_id, fornecedor_id)
VALUES ('Feijão Preto 1kg', 8.50, 40,
        (SELECT id FROM categoria WHERE nome = 'Alimentos'),
        (SELECT id FROM fornecedor WHERE cnpj = '12.345.678/0001-90'));

INSERT INTO produto (nome, preco, estoque, categoria_id, fornecedor_id)
VALUES ('Refrigerante 2L', 9.90, 100,
        (SELECT id FROM categoria WHERE nome = 'Bebidas'),
        (SELECT id FROM fornecedor WHERE cnpj = '98.765.432/0001-10'));
